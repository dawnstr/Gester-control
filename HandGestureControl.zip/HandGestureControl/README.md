# Hand Gesture Control (Android)

Control your phone with hand gestures seen by the front camera.

Pipeline: CameraX front camera -> MediaPipe Hand Landmarker -> GestureEngine (rule-based classifier)
-> AccessibilityService (taps, swipes, back, home, screenshot) + on-screen cursor overlay.

## Setup
1. Open this folder in Android Studio (Koala or newer). Let it sync Gradle.
2. Download the MediaPipe model and put it in `app/src/main/assets/`:
   ```
   curl -L -o app/src/main/assets/hand_landmarker.task \
     https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
   ```
3. Run on a physical Android 9+ phone (emulator cameras are poor for hand tracking).
4. In the app: grant camera permission -> enable the accessibility service
   (Settings > Accessibility > Hand Gesture Control) -> Start gesture control.

## Gestures
| Gesture | Action |
|---|---|
| Open palm, move hand around | Move cursor (follows palm center) |
| Quick thumb + index pinch | Tap at cursor (fires on release) |
| All-fingers pinch, hold 0.35s | Screenshot |
| Two fingers up, move hand up/down/left/right | Scroll or swipe left/right |
| Fist, hold 0.5s | Back |
| Thumbs up, hold 0.5s | Home |

All pose thresholds are ratios of the hand's own size in frame, so recognition works the same
whether your hand is close to or far from the camera. The camera analysis stream also requests
1280x960 and MediaPipe's detection confidence is lowered to 0.4, so a smaller, more distant hand
is still picked up.

## Tuning
Every threshold is in `Tuning` at the top of `GestureEngine.kt`. Common tweaks:
- Accidental triggers: raise `STABLE_FRAMES`, `HOLD_MS`, or `ALL_PINCH_HOLD_MS`.
- All-fingers pinch not detected: raise the `ALL_*` limits slightly.
- Fist vs. pinch confusion: adjust `MIN_REACH`.
- Cursor jittery: lower `CURSOR_SMOOTH`. Cursor laggy: raise it.
- Scroll/swipe too sensitive or not sensitive enough: adjust `FLING_SPEED`.
- Still slow to recognize at a distance: lower the confidence values in `CameraGestureService.kt`
  (`setMinHandDetectionConfidence` etc.) a bit further, or raise the resolution in
  `ResolutionStrategy` beyond 1280x960.

## Notes and limits
- Start tracking while the app is on screen (Android 14+ requires this for camera foreground services).
  It keeps running in the background with a notification that has a Stop button.
- The accessibility service must be enabled manually; Android does not allow apps to do this themselves.
- Google Play restricts accessibility-service apps, so this is best sideloaded or shipped as an assistive tool.
- Camera + ML use noticeable battery. Stop tracking when not needed.
- Designed for portrait use. Bright, even lighting and a hand about 30-60 cm from the camera work best.
- Some apps and secure screens (banking, DRM video) block screenshots and gestures by design.

## Build without Android Studio (GitHub Actions)
1. Create a GitHub repository and upload this whole project, including the `.github` folder.
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on every push
   (or click **Run workflow**). It downloads the MediaPipe model for you, so step 2 of Setup is not needed.
3. When it finishes, open the run and download the `HandGestureControl-debug-apk` artifact (a zip).
4. Unzip it, copy `app-debug.apk` to your phone, and install it
   (allow "Install unknown apps" for your file manager or browser when asked).
