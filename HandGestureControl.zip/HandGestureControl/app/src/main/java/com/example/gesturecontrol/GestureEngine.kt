package com.example.gesturecontrol

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.hypot

/** Actions the engine asks the accessibility service to perform. */
sealed class GestureEvent {
    /** Cursor position in screen space, 0..1 on both axes. */
    data class Cursor(val x: Float, val y: Float) : GestureEvent()
    data class Scroll(val swipeUp: Boolean) : GestureEvent()
    object Tap : GestureEvent()
    object Back : GestureEvent()
    object Home : GestureEvent()
    object Screenshot : GestureEvent()
}

enum class Pose { NONE, OPEN_PALM, POINT, PINCH, ALL_PINCH, FIST, PEACE }

/** All thresholds live here so they are easy to tune. Distances are relative to hand size. */
object Tuning {
    const val STABLE_FRAMES = 3            // frames a pose must persist before it counts
    const val EXTENDED_RATIO = 1.10f       // fingertip vs. PIP distance from wrist
    const val MIN_REACH = 1.10f            // index tip must be this far from wrist (separates pinch from fist)

    const val PINCH_INDEX = 0.25f          // thumb-index distance for a tap pinch

    const val ALL_INDEX = 0.35f            // thumb-to-fingertip limits for the all-fingers pinch
    const val ALL_MIDDLE = 0.35f
    const val ALL_RING = 0.40f
    const val ALL_PINKY = 0.45f

    const val CURSOR_FREEZE = 0.50f        // freeze cursor when fingertip closes in on thumb
    const val CURSOR_MARGIN = 0.15f        // unused camera border, lets you reach screen edges
    const val CURSOR_SMOOTH = 0.40f        // 0..1, higher = snappier, lower = smoother

    const val FLING_SPEED = 1.0f           // palm speed (frame heights / second) to trigger scroll
    const val SCROLL_COOLDOWN_MS = 600L

    const val MIN_TAP_MS = 60L
    const val MAX_TAP_MS = 700L
    const val TAP_COOLDOWN_MS = 400L

    const val ALL_PINCH_HOLD_MS = 500L     // screenshot
    const val HOLD_MS = 1000L              // back / home
    const val ACTION_COOLDOWN_MS = 800L
}

class GestureEngine(private val emit: (GestureEvent) -> Unit) {

    private var aspect = 0.75f             // frame width / height
    private var pose = Pose.NONE
    private var poseSince = 0L
    private var candidate = Pose.NONE
    private var candidateFrames = 0
    private var fired = false
    private var cooldownUntil = 0L

    private var cursorX = 0.5f
    private var cursorY = 0.5f
    private var cursorReady = false

    private var lastPalmY = 0f
    private var lastPalmT = 0L
    private var lastScrollAt = 0L

    fun onHandLost() {
        pose = Pose.NONE
        candidate = Pose.NONE
        candidateFrames = 0
        fired = false
    }

    fun process(lm: List<NormalizedLandmark>, aspect: Float, now: Long) {
        this.aspect = aspect
        val raw = classify(lm)
        if (raw == candidate) candidateFrames++ else { candidate = raw; candidateFrames = 1 }

        if (candidate != pose && candidateFrames >= Tuning.STABLE_FRAMES) {
            val old = pose
            val heldMs = now - poseSince
            pose = candidate
            poseSince = now
            fired = false

            // Tap fires on release of a short pinch (unless it grew into an all-fingers pinch)
            if (old == Pose.PINCH && pose != Pose.ALL_PINCH &&
                heldMs in Tuning.MIN_TAP_MS..Tuning.MAX_TAP_MS && now >= cooldownUntil
            ) {
                cooldownUntil = now + Tuning.TAP_COOLDOWN_MS
                emit(GestureEvent.Tap)
            }
            if (pose == Pose.OPEN_PALM) {
                lastPalmY = lm[9].y()
                lastPalmT = now
            }
        }
        onHeld(lm, now)
    }

    private fun onHeld(lm: List<NormalizedLandmark>, now: Long) {
        val held = now - poseSince
        when (pose) {
            Pose.POINT -> updateCursor(lm)
            Pose.ALL_PINCH -> if (!fired && held >= Tuning.ALL_PINCH_HOLD_MS) fire(GestureEvent.Screenshot, now)
            Pose.FIST -> if (!fired && held >= Tuning.HOLD_MS) fire(GestureEvent.Back, now)
            Pose.PEACE -> if (!fired && held >= Tuning.HOLD_MS) fire(GestureEvent.Home, now)
            Pose.OPEN_PALM -> handleScroll(lm, now)
            else -> Unit
        }
    }

    private fun fire(event: GestureEvent, now: Long) {
        fired = true
        if (now >= cooldownUntil) {
            cooldownUntil = now + Tuning.ACTION_COOLDOWN_MS
            emit(event)
        }
    }

    private fun updateCursor(lm: List<NormalizedLandmark>) {
        val scale = handScale(lm)
        if (d(lm[4], lm[8]) / scale < Tuning.CURSOR_FREEZE) return // about to pinch: hold position

        val m = Tuning.CURSOR_MARGIN
        val span = 1f - 2f * m
        // Front camera frames are not mirrored, so flip x to make the cursor follow your hand
        val tx = (((1f - lm[8].x()) - m) / span).coerceIn(0f, 1f)
        val ty = ((lm[8].y() - m) / span).coerceIn(0f, 1f)
        if (!cursorReady) {
            cursorX = tx; cursorY = ty; cursorReady = true
        } else {
            cursorX += (tx - cursorX) * Tuning.CURSOR_SMOOTH
            cursorY += (ty - cursorY) * Tuning.CURSOR_SMOOTH
        }
        emit(GestureEvent.Cursor(cursorX, cursorY))
    }

    private fun handleScroll(lm: List<NormalizedLandmark>, now: Long) {
        val y = lm[9].y()
        val dt = (now - lastPalmT).coerceAtLeast(1L)
        val speed = (y - lastPalmY) / dt * 1000f
        lastPalmY = y
        lastPalmT = now
        if (abs(speed) > Tuning.FLING_SPEED && now - lastScrollAt > Tuning.SCROLL_COOLDOWN_MS) {
            lastScrollAt = now
            emit(GestureEvent.Scroll(swipeUp = speed < 0)) // hand moves up -> swipe up (touch-style)
        }
    }

    private fun classify(lm: List<NormalizedLandmark>): Pose {
        val scale = handScale(lm)
        fun extended(tip: Int, pip: Int) = d(lm[0], lm[tip]) > d(lm[0], lm[pip]) * Tuning.EXTENDED_RATIO

        val index = extended(8, 6)
        val middle = extended(12, 10)
        val ring = extended(16, 14)
        val pinky = extended(20, 18)

        val thumb = lm[4]
        val pIndex = d(thumb, lm[8]) / scale
        val pMiddle = d(thumb, lm[12]) / scale
        val pRing = d(thumb, lm[16]) / scale
        val pPinky = d(thumb, lm[20]) / scale
        val reach = d(lm[0], lm[8]) / scale

        if (reach > Tuning.MIN_REACH &&
            pIndex < Tuning.ALL_INDEX && pMiddle < Tuning.ALL_MIDDLE &&
            pRing < Tuning.ALL_RING && pPinky < Tuning.ALL_PINKY
        ) return Pose.ALL_PINCH

        if (reach > Tuning.MIN_REACH && pIndex < Tuning.PINCH_INDEX) return Pose.PINCH

        return when {
            index && middle && ring && pinky -> Pose.OPEN_PALM
            index && middle && !ring && !pinky -> Pose.PEACE
            index && !middle && !ring && !pinky -> Pose.POINT
            !index && !middle && !ring && !pinky -> Pose.FIST
            else -> Pose.NONE
        }
    }

    private fun handScale(lm: List<NormalizedLandmark>) = d(lm[0], lm[9]).coerceAtLeast(1e-4f)

    /** Distance in "frame height" units (x is scaled by aspect ratio so distances aren't skewed). */
    private fun d(a: NormalizedLandmark, b: NormalizedLandmark) =
        hypot((a.x() - b.x()) * aspect, a.y() - b.y())
}
