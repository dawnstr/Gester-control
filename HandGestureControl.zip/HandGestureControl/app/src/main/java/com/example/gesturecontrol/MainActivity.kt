package com.example.gesturecontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, pad) }
        root.addView(status)
        root.addView(button("1. Grant camera permission") { askPermissions() })
        root.addView(button("2. Turn on accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("3. Start gesture control") { startTracking() })
        root.addView(button("Stop") {
            stopService(Intent(this, CameraGestureService::class.java))
            refresh()
        })
        root.addView(TextView(this).apply {
            text = HELP
            textSize = 15f
            setPadding(0, pad, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        setOnClickListener { onClick() }
    }

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun accessibilityOn() = GestureAccessibilityService.instance != null

    private fun refresh() {
        status.text = "${if (hasCamera()) "✅" else "❌"} Camera permission\n" +
            "${if (accessibilityOn()) "✅" else "❌"} Accessibility service"
    }

    private fun askPermissions() {
        val perms = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(perms.toTypedArray())
    }

    private fun startTracking() {
        if (!hasCamera()) return toast("Grant camera permission first")
        if (!accessibilityOn()) return toast("Turn on the accessibility service first")
        ContextCompat.startForegroundService(this, Intent(this, CameraGestureService::class.java))
        toast("Gesture control started. Hold the phone upright and show your hand.")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private companion object {
        val HELP = """
            Gestures
            ✋ Open palm, move hand around: move cursor
            🤏 Quick thumb + index pinch: tap
            🤌 All fingers pinch, hold 0.35s: screenshot
            ✌️ Two fingers, move hand up/down/left/right: scroll or swipe
            ✊ Fist, hold 0.5s: back
            👍 Thumbs up, hold 0.5s: home
        """.trimIndent()
    }
}
