package com.example.gesturecontrol

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.view.View

/** Full-screen, non-touchable overlay that draws the gesture cursor. */
class CursorOverlayView(context: Context) : View(context) {

    private var cx = -100f
    private var cy = -100f
    private var flashUntil = 0L

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = 0xFF00E5FF.toInt()
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xAA00E5FF.toInt()
    }

    fun moveTo(x: Float, y: Float) {
        cx = x
        cy = y
        invalidate()
    }

    fun flash() {
        flashUntil = SystemClock.uptimeMillis() + 150
        invalidate()
        postInvalidateDelayed(170)
    }

    override fun onDraw(canvas: Canvas) {
        val flashing = SystemClock.uptimeMillis() < flashUntil
        canvas.drawCircle(cx, cy, if (flashing) 46f else 30f, ring)
        canvas.drawCircle(cx, cy, 8f, dot)
    }
}
