package com.example.gesturecontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.hardware.display.DisplayManager
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.Executors

/**
 * Foreground service: front camera -> MediaPipe hand landmarks -> GestureEngine -> accessibility service.
 * Must be started while the app is visible (Android 14+ rule for camera foreground services).
 */
class CameraGestureService : LifecycleService() {

    companion object {
        private const val TAG = "CameraGestureService"
        private const val CHANNEL_ID = "gesture_control"
        private const val NOTIFICATION_ID = 1
        private const val ACTION_STOP = "com.example.gesturecontrol.STOP"
        private const val MODEL_ASSET = "hand_landmarker.task"
    }

    private lateinit var landmarker: HandLandmarker
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val engine = GestureEngine { GestureAccessibilityService.instance?.handle(it) }
    private var cameraStarted = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        )
        try {
            setUpLandmarker()
        } catch (e: Exception) {
            Log.e(TAG, "Could not load $MODEL_ASSET", e)
            Toast.makeText(this, "Missing $MODEL_ASSET in app/src/main/assets", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!cameraStarted && ::landmarker.isInitialized) {
            cameraStarted = true
            bindCamera()
            GestureAccessibilityService.instance?.setActive(true)
        }
        return START_NOT_STICKY
    }

    private fun setUpLandmarker() {
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL_ASSET).build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.4f)
            .setMinHandPresenceConfidence(0.4f)
            .setMinTrackingConfidence(0.4f)
            .setResultListener { result, input -> onResult(result, input) }
            .setErrorListener { e -> Log.e(TAG, "MediaPipe error", e) }
            .build()
        landmarker = HandLandmarker.createFromOptions(this, options)
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val rotation = getSystemService(DisplayManager::class.java)
                .getDisplay(Display.DEFAULT_DISPLAY).rotation
            val resolutionSelector = androidx.camera.core.resolutionselector.ResolutionSelector.Builder()
                .setResolutionStrategy(
                    androidx.camera.core.resolutionselector.ResolutionStrategy(
                        android.util.Size(1280, 960),
                        androidx.camera.core.resolutionselector.ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                    )
                )
                .build()
            val analysis = ImageAnalysis.Builder()
                .setTargetRotation(rotation)
                .setResolutionSelector(resolutionSelector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(analysisExecutor) { proxy -> analyze(proxy) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val upright: Bitmap = try {
            val raw = proxy.toBitmap()
            val matrix = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
        } finally {
            proxy.close()
        }
        landmarker.detectAsync(BitmapImageBuilder(upright).build(), SystemClock.uptimeMillis())
    }

    private fun onResult(result: HandLandmarkerResult, input: MPImage) {
        val hand = result.landmarks().firstOrNull()
        if (hand == null || hand.size < 21) {
            engine.onHandLost()
            return
        }
        engine.process(hand, input.width.toFloat() / input.height, SystemClock.uptimeMillis())
    }

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Gesture control", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, CameraGestureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Gesture control is on")
            .setContentText("The front camera is tracking your hand")
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
    }

    override fun onDestroy() {
        GestureAccessibilityService.instance?.setActive(false)
        if (::landmarker.isInitialized) landmarker.close()
        analysisExecutor.shutdown()
        super.onDestroy()
    }
}
