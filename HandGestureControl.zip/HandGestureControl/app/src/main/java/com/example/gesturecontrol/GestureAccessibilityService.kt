package com.example.gesturecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Turns GestureEvents into real system actions. The user must enable this service
 * manually in Settings > Accessibility.
 */
class GestureAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GestureAccessibilityService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var overlay: CursorOverlayView? = null
    private var cursorX = 0f
    private var cursorY = 0f

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val view = CursorOverlayView(this).apply { visibility = View.GONE }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(view, params)
        overlay = view
        cursorX = resources.displayMetrics.widthPixels / 2f
        cursorY = resources.displayMetrics.heightPixels / 2f
    }

    /** Called by the camera service so the cursor only shows while tracking is on. */
    fun setActive(active: Boolean) {
        main.post { overlay?.visibility = if (active) View.VISIBLE else View.GONE }
    }

    /** Safe to call from any thread. */
    fun handle(event: GestureEvent) {
        main.post {
            val w = resources.displayMetrics.widthPixels.toFloat()
            val h = resources.displayMetrics.heightPixels.toFloat()
            when (event) {
                is GestureEvent.Cursor -> {
                    cursorX = event.x * w
                    cursorY = event.y * h
                    overlay?.moveTo(cursorX, cursorY)
                }
                GestureEvent.Tap -> {
                    overlay?.flash()
                    tapAt(cursorX, cursorY)
                }
                is GestureEvent.Scroll -> swipeVertical(w, h, event.swipeUp)
                GestureEvent.Back -> performGlobalAction(GLOBAL_ACTION_BACK)
                GestureEvent.Home -> performGlobalAction(GLOBAL_ACTION_HOME)
                GestureEvent.Screenshot -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            }
        }
    }

    private fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun swipeVertical(w: Float, h: Float, swipeUp: Boolean) {
        val path = Path().apply {
            moveTo(w / 2f, if (swipeUp) h * 0.70f else h * 0.30f)
            lineTo(w / 2f, if (swipeUp) h * 0.30f else h * 0.70f)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 250)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        removeOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeOverlay()
        instance = null
        super.onDestroy()
    }

    private fun removeOverlay() {
        overlay?.let { runCatching { windowManager?.removeView(it) } }
        overlay = null
    }
}
